# Courier Tracker Mobile App

A React Native mobile application for real-time GPS tracking of courier deliveries.

## Quick Setup

### For Testing (Expo Go)
1. Install Expo Go app on your phone
2. Run these commands:
```bash
cd mobile-app
npm install
npm start
```
3. Scan QR code with Expo Go app
4. Login with: owner@company.com / admin123

### For Production Deployment
1. Update API URL in `src/services/apiService.ts`
2. Build app:
```bash
npm install -g @expo/eas-cli
eas build:configure
eas build --platform android
```

## Features
- Real-time GPS tracking (5-second intervals)
- Status management (Available/Busy/Offline)
- Background location tracking
- Secure authentication
- Battery optimization

## Courier Instructions
1. Download and install app
2. Enable location permissions ("Allow all the time")
3. Login with courier credentials
4. Start GPS tracking before work shift
5. Keep app running in background during deliveries

## Admin Dashboard
View real-time courier locations at: `/gps-tracking` page in web dashboard