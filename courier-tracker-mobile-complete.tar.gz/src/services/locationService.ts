import * as Location from 'expo-location';
import { LocationUpdate } from '../types';
import apiService from './apiService';

class LocationService {
  private watchId: Location.LocationSubscription | null = null;
  private courierId: number | null = null;
  private isTracking = false;

  async requestPermissions(): Promise<boolean> {
    try {
      const { status: foregroundStatus } = await Location.requestForegroundPermissionsAsync();
      if (foregroundStatus !== 'granted') {
        return false;
      }

      const { status: backgroundStatus } = await Location.requestBackgroundPermissionsAsync();
      if (backgroundStatus !== 'granted') {
        console.warn('Background location permission not granted');
        // Still allow foreground tracking
      }

      return true;
    } catch (error) {
      console.error('Error requesting location permissions:', error);
      return false;
    }
  }

  async startTracking(courierId: number): Promise<boolean> {
    if (this.isTracking) {
      return true;
    }

    const hasPermission = await this.requestPermissions();
    if (!hasPermission) {
      throw new Error('Location permission denied');
    }

    this.courierId = courierId;

    try {
      this.watchId = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.BestForNavigation,
          timeInterval: 5000, // Update every 5 seconds
          distanceInterval: 10, // Update every 10 meters
        },
        (location) => {
          this.handleLocationUpdate(location);
        }
      );

      this.isTracking = true;
      return true;
    } catch (error) {
      console.error('Error starting location tracking:', error);
      return false;
    }
  }

  stopTracking(): void {
    if (this.watchId) {
      this.watchId.remove();
      this.watchId = null;
    }
    this.isTracking = false;
    this.courierId = null;
  }

  private async handleLocationUpdate(location: Location.LocationObject): Promise<void> {
    if (!this.courierId) return;

    const locationUpdate: LocationUpdate = {
      courierId: this.courierId,
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
      timestamp: new Date(),
      accuracy: location.coords.accuracy || 0,
      speed: location.coords.speed || undefined,
      heading: location.coords.heading || undefined,
    };

    try {
      await apiService.updateLocation(locationUpdate);
    } catch (error) {
      console.error('Failed to send location update:', error);
    }
  }

  async getCurrentPosition(): Promise<Location.LocationObject | null> {
    try {
      const hasPermission = await this.requestPermissions();
      if (!hasPermission) {
        return null;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.BestForNavigation,
      });

      return location;
    } catch (error) {
      console.error('Error getting current position:', error);
      return null;
    }
  }

  isCurrentlyTracking(): boolean {
    return this.isTracking;
  }
}

export default new LocationService();