import axios from 'axios';
import { LocationUpdate, AuthResponse, Courier } from '../types';

// Use your actual server URL - replace with your Replit app URL
const BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:5000';

class ApiService {
  private token: string | null = null;

  setToken(token: string) {
    this.token = token;
  }

  private getHeaders() {
    return {
      'Content-Type': 'application/json',
      ...(this.token && { Authorization: `Bearer ${this.token}` }),
    };
  }

  async login(email: string, password: string): Promise<AuthResponse> {
    try {
      const response = await axios.post(`${BASE_URL}/api/login`, {
        email,
        password,
      });
      return response.data;
    } catch (error) {
      throw new Error('Login failed');
    }
  }

  async updateLocation(locationData: LocationUpdate): Promise<void> {
    try {
      await axios.post(`${BASE_URL}/api/couriers/location`, locationData, {
        headers: this.getHeaders(),
      });
    } catch (error) {
      console.error('Failed to update location:', error);
      throw error;
    }
  }

  async getAllCouriers(): Promise<Courier[]> {
    try {
      const response = await axios.get(`${BASE_URL}/api/couriers`, {
        headers: this.getHeaders(),
      });
      return response.data;
    } catch (error) {
      console.error('Failed to fetch couriers:', error);
      throw error;
    }
  }

  async getCourierLocation(courierId: number): Promise<LocationUpdate | null> {
    try {
      const response = await axios.get(`${BASE_URL}/api/couriers/${courierId}/location`, {
        headers: this.getHeaders(),
      });
      return response.data;
    } catch (error) {
      console.error('Failed to fetch courier location:', error);
      return null;
    }
  }

  async updateCourierStatus(courierId: number, status: 'available' | 'busy' | 'offline'): Promise<void> {
    try {
      await axios.patch(`${BASE_URL}/api/couriers/${courierId}/status`, 
        { status },
        { headers: this.getHeaders() }
      );
    } catch (error) {
      console.error('Failed to update courier status:', error);
      throw error;
    }
  }
}

export default new ApiService();