import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
} from 'react-native';
import {
  Card,
  Title,
  Paragraph,
  Button,
  List,
  Chip,
  Divider,
} from 'react-native-paper';
import { User } from '../types';

interface CourierDashboardProps {
  navigation: any;
  route: {
    params: {
      user: User;
    };
  };
}

export default function CourierDashboard({ navigation, route }: CourierDashboardProps) {
  const { user } = route.params;
  const [courierData, setCourierData] = useState<any>(null);

  useEffect(() => {
    // Load courier-specific data
    loadCourierData();
  }, []);

  const loadCourierData = async () => {
    // This would fetch courier-specific data from your API
    // For now, we'll use mock data structure
    setCourierData({
      id: 1,
      name: `${user.firstName} ${user.lastName}`,
      todayDeliveries: 8,
      totalEarnings: 450.50,
      currentStatus: 'available',
    });
  };

  const startGPSTracking = () => {
    navigation.navigate('GPSTracking', { 
      user, 
      courierId: courierData?.id || 1 
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.welcomeCard}>
        <Card.Content>
          <Title>Welcome, {user.firstName}!</Title>
          <Paragraph>Ready to start your delivery shift?</Paragraph>
        </Card.Content>
      </Card>

      <Card style={styles.statsCard}>
        <Card.Content>
          <Title>Today's Performance</Title>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Title style={styles.statNumber}>8</Title>
              <Paragraph>Deliveries</Paragraph>
            </View>
            <View style={styles.statItem}>
              <Title style={styles.statNumber}>450.50</Title>
              <Paragraph>Earnings (SAR)</Paragraph>
            </View>
          </View>
        </Card.Content>
      </Card>

      <Card style={styles.actionsCard}>
        <Card.Content>
          <Title>Quick Actions</Title>
          <List.Section>
            <List.Item
              title="Start GPS Tracking"
              description="Begin location tracking for deliveries"
              left={props => <List.Icon {...props} icon="map-marker" />}
              onPress={startGPSTracking}
            />
            <Divider />
            <List.Item
              title="View Orders"
              description="Check assigned delivery orders"
              left={props => <List.Icon {...props} icon="package-variant" />}
              onPress={() => {/* Navigate to orders */}}
            />
            <Divider />
            <List.Item
              title="Report Issue"
              description="Report delivery or vehicle issues"
              left={props => <List.Icon {...props} icon="alert-circle" />}
              onPress={() => {/* Navigate to issue reporting */}}
            />
          </List.Section>
        </Card.Content>
      </Card>

      <Card style={styles.statusCard}>
        <Card.Content>
          <Title>Current Status</Title>
          <View style={styles.statusContainer}>
            <Chip 
              style={[styles.statusChip, { backgroundColor: '#10B981' }]}
              textStyle={styles.statusText}
            >
              AVAILABLE
            </Chip>
            <Button
              mode="outlined"
              onPress={() => {/* Change status */}}
              style={styles.statusButton}
            >
              Change Status
            </Button>
          </View>
        </Card.Content>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F5F5F5',
  },
  welcomeCard: {
    marginBottom: 16,
    elevation: 4,
  },
  statsCard: {
    marginBottom: 16,
    elevation: 4,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3B82F6',
  },
  actionsCard: {
    marginBottom: 16,
    elevation: 4,
  },
  statusCard: {
    marginBottom: 16,
    elevation: 4,
  },
  statusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
  },
  statusChip: {
    paddingHorizontal: 16,
  },
  statusText: {
    color: 'white',
    fontWeight: 'bold',
  },
  statusButton: {
    minWidth: 120,
  },
});