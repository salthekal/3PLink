import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  Text,
} from 'react-native';
import {
  Button,
  Card,
  Title,
  Paragraph,
  Switch,
  ActivityIndicator,
  Chip,
} from 'react-native-paper';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import locationService from '../services/locationService';
import apiService from '../services/apiService';

interface GPSTrackingScreenProps {
  navigation: any;
  route: {
    params: {
      user: any;
      courierId: number;
    };
  };
}

export default function GPSTrackingScreen({ navigation, route }: GPSTrackingScreenProps) {
  const { user, courierId } = route.params;
  const [isTracking, setIsTracking] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<Location.LocationObject | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'available' | 'busy' | 'offline'>('available');

  useEffect(() => {
    getCurrentLocation();
    return () => {
      if (isTracking) {
        locationService.stopTracking();
      }
    };
  }, []);

  const getCurrentLocation = async () => {
    const location = await locationService.getCurrentPosition();
    if (location) {
      setCurrentLocation(location);
    }
  };

  const toggleTracking = async () => {
    if (isTracking) {
      locationService.stopTracking();
      setIsTracking(false);
      setStatus('offline');
      await apiService.updateCourierStatus(courierId, 'offline');
    } else {
      setLoading(true);
      try {
        const success = await locationService.startTracking(courierId);
        if (success) {
          setIsTracking(true);
          setStatus('available');
          await apiService.updateCourierStatus(courierId, 'available');
          Alert.alert('Success', 'GPS tracking started');
        } else {
          Alert.alert('Error', 'Failed to start GPS tracking');
        }
      } catch (error: any) {
        Alert.alert('Error', error.message || 'Failed to start tracking');
      } finally {
        setLoading(false);
      }
    }
  };

  const updateStatus = async (newStatus: 'available' | 'busy' | 'offline') => {
    try {
      await apiService.updateCourierStatus(courierId, newStatus);
      setStatus(newStatus);
    } catch (error) {
      Alert.alert('Error', 'Failed to update status');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return '#10B981';
      case 'busy': return '#F59E0B';
      case 'offline': return '#EF4444';
      default: return '#6B7280';
    }
  };

  return (
    <View style={styles.container}>
      {currentLocation && (
        <MapView
          style={styles.map}
          provider={PROVIDER_GOOGLE}
          initialRegion={{
            latitude: currentLocation.coords.latitude,
            longitude: currentLocation.coords.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          }}
          showsUserLocation={true}
          showsMyLocationButton={true}
          followUserLocation={true}
        >
          <Marker
            coordinate={{
              latitude: currentLocation.coords.latitude,
              longitude: currentLocation.coords.longitude,
            }}
            title="Your Location"
            description="Current position"
          />
        </MapView>
      )}

      <Card style={styles.controlPanel}>
        <Card.Content>
          <Title>GPS Tracking Control</Title>
          
          <View style={styles.statusContainer}>
            <Text style={styles.statusLabel}>Status:</Text>
            <Chip 
              style={[styles.statusChip, { backgroundColor: getStatusColor(status) }]}
              textStyle={styles.statusText}
            >
              {status.toUpperCase()}
            </Chip>
          </View>

          <View style={styles.trackingContainer}>
            <Paragraph>GPS Tracking</Paragraph>
            <View style={styles.switchContainer}>
              {loading ? (
                <ActivityIndicator size="small" />
              ) : (
                <Switch
                  value={isTracking}
                  onValueChange={toggleTracking}
                />
              )}
            </View>
          </View>

          <View style={styles.statusButtons}>
            <Button
              mode={status === 'available' ? 'contained' : 'outlined'}
              onPress={() => updateStatus('available')}
              style={styles.statusButton}
              buttonColor={status === 'available' ? '#10B981' : undefined}
            >
              Available
            </Button>
            <Button
              mode={status === 'busy' ? 'contained' : 'outlined'}
              onPress={() => updateStatus('busy')}
              style={styles.statusButton}
              buttonColor={status === 'busy' ? '#F59E0B' : undefined}
            >
              Busy
            </Button>
          </View>

          {currentLocation && (
            <View style={styles.locationInfo}>
              <Paragraph style={styles.infoText}>
                Lat: {currentLocation.coords.latitude.toFixed(6)}
              </Paragraph>
              <Paragraph style={styles.infoText}>
                Lng: {currentLocation.coords.longitude.toFixed(6)}
              </Paragraph>
              <Paragraph style={styles.infoText}>
                Accuracy: ±{currentLocation.coords.accuracy?.toFixed(0)}m
              </Paragraph>
            </View>
          )}
        </Card.Content>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  controlPanel: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    elevation: 8,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  statusLabel: {
    fontSize: 16,
    marginRight: 8,
  },
  statusChip: {
    paddingHorizontal: 8,
  },
  statusText: {
    color: 'white',
    fontWeight: 'bold',
  },
  trackingContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  switchContainer: {
    minWidth: 50,
    alignItems: 'center',
  },
  statusButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  statusButton: {
    flex: 1,
    marginHorizontal: 4,
  },
  locationInfo: {
    backgroundColor: '#F3F4F6',
    padding: 8,
    borderRadius: 4,
  },
  infoText: {
    fontSize: 12,
    color: '#374151',
  },
});