import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  RefreshControl,
} from 'react-native';
import {
  Card,
  Title,
  List,
  FAB,
  Chip,
  ActivityIndicator,
} from 'react-native-paper';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import apiService from '../services/apiService';
import { Courier } from '../types';

interface AdminTrackingScreenProps {
  navigation: any;
  route: {
    params: {
      user: any;
    };
  };
}

export default function AdminTrackingScreen({ navigation, route }: AdminTrackingScreenProps) {
  const { user } = route.params;
  const [couriers, setCouriers] = useState<Courier[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCourier, setSelectedCourier] = useState<Courier | null>(null);
  const [mapRegion, setMapRegion] = useState({
    latitude: 24.7136,  // Riyadh coordinates
    longitude: 46.6753,
    latitudeDelta: 0.1,
    longitudeDelta: 0.1,
  });

  useEffect(() => {
    loadCouriers();
    const interval = setInterval(loadCouriers, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const loadCouriers = async () => {
    try {
      const courierData = await apiService.getAllCouriers();
      setCouriers(courierData);
      
      // If there are active couriers, center map on them
      const activeCouriers = courierData.filter(c => c.currentLocation);
      if (activeCouriers.length > 0) {
        const avgLat = activeCouriers.reduce((sum, c) => sum + (c.currentLocation?.latitude || 0), 0) / activeCouriers.length;
        const avgLng = activeCouriers.reduce((sum, c) => sum + (c.currentLocation?.longitude || 0), 0) / activeCouriers.length;
        setMapRegion({
          latitude: avgLat,
          longitude: avgLng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }
    } catch (error) {
      console.error('Failed to load couriers:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadCouriers();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return '#10B981';
      case 'busy': return '#F59E0B';
      case 'offline': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getLastUpdateTime = (timestamp?: Date) => {
    if (!timestamp) return 'No location data';
    const now = new Date();
    const diff = now.getTime() - new Date(timestamp).getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" />
        <Title style={styles.loadingText}>Loading couriers...</Title>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        region={mapRegion}
        onRegionChangeComplete={setMapRegion}
      >
        {couriers
          .filter(courier => courier.currentLocation)
          .map(courier => (
            <Marker
              key={courier.id}
              coordinate={{
                latitude: courier.currentLocation!.latitude,
                longitude: courier.currentLocation!.longitude,
              }}
              title={courier.name}
              description={`Status: ${courier.status} | ${getLastUpdateTime(courier.currentLocation?.timestamp)}`}
              pinColor={getStatusColor(courier.status)}
              onPress={() => setSelectedCourier(courier)}
            />
          ))}
      </MapView>

      <Card style={styles.courierList}>
        <Card.Content>
          <Title>Active Couriers ({couriers.filter(c => c.status !== 'offline').length})</Title>
          <List.Section>
            {couriers.map(courier => (
              <List.Item
                key={courier.id}
                title={courier.name}
                description={`${courier.phone} | ${getLastUpdateTime(courier.currentLocation?.timestamp)}`}
                left={() => (
                  <Chip 
                    style={[styles.statusChip, { backgroundColor: getStatusColor(courier.status) }]}
                    textStyle={styles.statusText}
                    compact
                  >
                    {courier.status.charAt(0).toUpperCase()}
                  </Chip>
                )}
                right={() => courier.currentLocation && (
                  <View style={styles.accuracyContainer}>
                    <Chip 
                      compact 
                      style={styles.accuracyChip}
                      textStyle={styles.accuracyText}
                    >
                      ±{courier.currentLocation.accuracy?.toFixed(0)}m
                    </Chip>
                  </View>
                )}
                onPress={() => {
                  if (courier.currentLocation) {
                    setMapRegion({
                      latitude: courier.currentLocation.latitude,
                      longitude: courier.currentLocation.longitude,
                      latitudeDelta: 0.01,
                      longitudeDelta: 0.01,
                    });
                    setSelectedCourier(courier);
                  }
                }}
              />
            ))}
          </List.Section>
        </Card.Content>
      </Card>

      {selectedCourier && selectedCourier.currentLocation && (
        <Card style={styles.selectedCourierCard}>
          <Card.Content>
            <Title>{selectedCourier.name}</Title>
            <View style={styles.courierDetails}>
              <Chip 
                style={[styles.statusChip, { backgroundColor: getStatusColor(selectedCourier.status) }]}
                textStyle={styles.statusText}
              >
                {selectedCourier.status.toUpperCase()}
              </Chip>
              <Chip style={styles.detailChip}>
                {selectedCourier.currentLocation.latitude.toFixed(6)}, {selectedCourier.currentLocation.longitude.toFixed(6)}
              </Chip>
              {selectedCourier.currentLocation.speed && (
                <Chip style={styles.detailChip}>
                  {Math.round(selectedCourier.currentLocation.speed * 3.6)} km/h
                </Chip>
              )}
            </View>
          </Card.Content>
        </Card>
      )}

      <FAB
        style={styles.fab}
        icon="refresh"
        onPress={onRefresh}
        loading={refreshing}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
  },
  map: {
    flex: 1,
  },
  courierList: {
    position: 'absolute',
    top: 20,
    left: 20,
    right: 20,
    maxHeight: '40%',
    elevation: 8,
  },
  selectedCourierCard: {
    position: 'absolute',
    bottom: 80,
    left: 20,
    right: 20,
    elevation: 8,
  },
  courierDetails: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  statusChip: {
    marginRight: 8,
  },
  statusText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
  },
  detailChip: {
    backgroundColor: '#F3F4F6',
  },
  accuracyContainer: {
    justifyContent: 'center',
  },
  accuracyChip: {
    backgroundColor: '#E5E7EB',
  },
  accuracyText: {
    fontSize: 10,
    color: '#374151',
  },
  fab: {
    position: 'absolute',
    bottom: 20,
    right: 20,
  },
});