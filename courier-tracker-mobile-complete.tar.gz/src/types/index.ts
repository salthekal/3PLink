export interface Courier {
  id: number;
  name: string;
  email: string;
  phone: string;
  isActive: boolean;
  currentLocation?: {
    latitude: number;
    longitude: number;
    timestamp: Date;
    accuracy: number;
    speed?: number;
    heading?: number;
  };
  status: 'available' | 'busy' | 'offline';
}

export interface LocationUpdate {
  courierId: number;
  latitude: number;
  longitude: number;
  timestamp: Date;
  accuracy: number;
  speed?: number;
  heading?: number;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: {
    name: string;
    permissions: string[];
  };
}

export interface AuthResponse {
  user: User;
  token?: string;
}