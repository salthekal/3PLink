import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider } from 'react-native-paper';
import LoginScreen from './src/screens/LoginScreen';
import CourierDashboard from './src/screens/CourierDashboard';
import GPSTrackingScreen from './src/screens/GPSTrackingScreen';
import AdminTrackingScreen from './src/screens/AdminTrackingScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen 
            name="Login" 
            component={LoginScreen}
            options={{ headerShown: false }}
          />
          <Stack.Screen 
            name="CourierDashboard" 
            component={CourierDashboard}
            options={{ title: 'Courier Dashboard' }}
          />
          <Stack.Screen 
            name="GPSTracking" 
            component={GPSTrackingScreen}
            options={{ title: 'GPS Tracking' }}
          />
          <Stack.Screen 
            name="AdminTracking" 
            component={AdminTrackingScreen}
            options={{ title: 'Live Courier Tracking' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}